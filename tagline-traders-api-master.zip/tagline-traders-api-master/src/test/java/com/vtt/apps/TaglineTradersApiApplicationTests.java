package com.vtt.apps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaglineTradersApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
