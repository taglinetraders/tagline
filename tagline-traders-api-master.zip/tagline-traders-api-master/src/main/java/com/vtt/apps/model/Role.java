package com.vtt.apps.model;


/**
 * @author lskumar
 * @date 2020-02-09
 * @time 12:52
 */

public enum Role
{
    ROLE_USER,
    ROLE_ADMIN
}
