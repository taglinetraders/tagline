package com.vtt.apps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TaglineTradersApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaglineTradersApiApplication.class, args);
	}

}
