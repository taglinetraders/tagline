# tagline-traders-api

NEW URL for SWAGGER UI :
========================
http://localhost:8080/swagger-ui/ or 
http://localhost:8080/swagger-ui/index.html

http://localhost:8080/v2/api-docs

Sequence No for CAT,SUB,PRODUCT  Needs to be implemented  - [https://www.callicoder.com/spring-boot-jpa-hibernate-postgresql-restful-crud-api-example/]
