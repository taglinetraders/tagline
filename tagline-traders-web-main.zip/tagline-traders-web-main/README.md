# tagline-traders-web
tagline-traders-web React App for the Front End
